import os
from vedio_music_merge import merge_two
#待处理文件
pre_video='ssss.mp4'
#这个就是所有的合并操作
merge_two(pre_video)
